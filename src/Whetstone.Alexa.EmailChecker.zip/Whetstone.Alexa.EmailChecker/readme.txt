To get the JSON skill manifest:

ask api get-skill -s amzn1.ask.skill.64912b85-a1db-4da5-b721-1e8d1d45b0a6 > skill.json

To update the skill manfest:

ask api update-skill –s amzn1.ask.skill.64912b85-a1db-4da5-b721-1e8d1d45b0a6 –f skill.json